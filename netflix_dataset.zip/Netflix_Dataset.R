#Loading Library
library(ggplot2)

#Load Data
df <- read.csv("C:/Users/emode/Downloads/netflix_data.zip")

#Creating a visualization
ggplot(df, aes(x=title)) + geom_bar() + labs(title = 'Most Watched movies', x='Title', y='Count') + theme(axis.text.x = element_text(angle=45, hjust=1))



